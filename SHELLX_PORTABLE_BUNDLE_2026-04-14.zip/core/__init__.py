# ShellX portable core package
